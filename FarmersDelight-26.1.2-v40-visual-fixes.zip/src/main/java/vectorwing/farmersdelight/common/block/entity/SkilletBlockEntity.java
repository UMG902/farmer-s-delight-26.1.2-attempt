package vectorwing.farmersdelight.common.block.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Clearable;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.ItemStackHandler;
import vectorwing.farmersdelight.common.block.SkilletBlock;
import vectorwing.farmersdelight.common.registry.ModBlockEntityTypes;
import vectorwing.farmersdelight.common.registry.ModItems;
import vectorwing.farmersdelight.common.registry.ModParticleTypes;
import vectorwing.farmersdelight.common.registry.ModSounds;
import vectorwing.farmersdelight.common.utility.ItemUtils;
import vectorwing.farmersdelight.common.utility.TextUtils;

import java.util.Optional;

public class SkilletBlockEntity extends SyncedBlockEntity implements HeatableBlockEntity, Clearable
{
	private final ItemStackHandler inventory = createHandler();
	private int cookingTime;
	private int cookingTimeTotal;

	private ItemStack skilletStack;
	private int fireAspectLevel;

	private final RecipeManager.CachedCheck<SingleRecipeInput, CampfireCookingRecipe> quickCheck;

	public SkilletBlockEntity(BlockPos pos, BlockState state) {
		super(ModBlockEntityTypes.SKILLET.get(), pos, state);
		skilletStack = new ItemStack(ModItems.SKILLET.get());
		quickCheck = RecipeManager.createCheck(RecipeType.CAMPFIRE_COOKING);
	}

	public static void cookingTick(Level level, BlockPos pos, BlockState state, SkilletBlockEntity skillet) {
		boolean isHeated = skillet.isHeated(level, pos);

		if (state.getValue(SkilletBlock.WATERLOGGED)) {
			if (ItemUtils.doesInventoryHaveItems(skillet.inventory)) {
				ItemUtils.dropItems(level, pos, skillet.inventory);
				skillet.inventoryChanged();
			}
		} else if (isHeated) {
			ItemStack cookingStack = skillet.getStoredStack();
			if (cookingStack.isEmpty()) {
				skillet.cookingTime = 0;
			} else {
				skillet.cookAndOutputItems(cookingStack, level);
			}
		} else if (skillet.cookingTime > 0) {
			skillet.cookingTime = Mth.clamp(skillet.cookingTime - 2, 0, skillet.cookingTimeTotal);
		}
	}

	public static void animationTick(Level level, BlockPos pos, BlockState state, SkilletBlockEntity skillet) {
		if (skillet.isHeated(level, pos) && skillet.hasStoredStack()) {
			RandomSource random = level.getRandom();
			if (random.nextFloat() < 0.2F) {
				double x = (double) pos.getX() + 0.5D + (random.nextDouble() * 0.4D - 0.2D);
				double y = (double) pos.getY() + 0.1D;
				double z = (double) pos.getZ() + 0.5D + (random.nextDouble() * 0.4D - 0.2D);
				double motionY = random.nextBoolean() ? 0.015D : 0.005D;
				level.addParticle(ModParticleTypes.STEAM.get(), x, y, z, 0.0D, motionY, 0.0D);
			}
			if (skillet.fireAspectLevel > 0 && random.nextFloat() < skillet.fireAspectLevel * 0.05F) {
				double x = (double) pos.getX() + 0.5D + (random.nextDouble() * 0.4D - 0.2D);
				double y = (double) pos.getY() + 0.1D;
				double z = (double) pos.getZ() + 0.5D + (random.nextDouble() * 0.4D - 0.2D);
				double motionX = level.getRandom().nextFloat() - 0.5F;
				double motionY = level.getRandom().nextFloat() * 0.5F + 0.2f;
				double motionZ = level.getRandom().nextFloat() - 0.5F;
				level.addParticle(ParticleTypes.ENCHANTED_HIT, x, y, z, motionX, motionY, motionZ);
			}
		}

	}

	private void cookAndOutputItems(ItemStack cookingStack, Level level) {
		++cookingTime;
		if (cookingTime >= cookingTimeTotal) {
			Optional<RecipeHolder<CampfireCookingRecipe>> recipe = getMatchingRecipe(cookingStack);
			if (recipe.isPresent()) {
				ItemStack resultStack = recipe.get().value().assemble(new SingleRecipeInput(cookingStack));
				Direction direction = getBlockState().getValue(SkilletBlock.FACING).getClockWise();
				ItemUtils.spawnItemEntity(level, resultStack.copy(),
						worldPosition.getX() + 0.5, worldPosition.getY() + 0.3, worldPosition.getZ() + 0.5,
						direction.getStepX() * 0.08F, 0.25F, direction.getStepZ() * 0.08F);

				cookingTime = 0;
				inventory.extractItem(0, 1, false);
			}
		}
	}

	public boolean isCooking() {
		return isHeated() && hasStoredStack();
	}

	public boolean isHeated() {
		if (level != null) {
			return isHeated(level, worldPosition);
		}
		return false;
	}

	private Optional<RecipeHolder<CampfireCookingRecipe>> getMatchingRecipe(ItemStack stack) {
		if (level == null) return Optional.empty();
		return this.level instanceof ServerLevel serverLevel ? this.quickCheck.getRecipeFor(new SingleRecipeInput(stack), serverLevel) : Optional.empty();
	}

	@Override
	public void loadAdditional(net.minecraft.world.level.storage.ValueInput input) {
		super.loadAdditional(input);
		inventory.deserialize(input);
		cookingTime = input.getIntOr("CookTime", 0);
		cookingTimeTotal = input.getIntOr("CookTimeTotal", 0);
		skilletStack = input.read("Skillet", ItemStack.CODEC).orElse(ItemStack.EMPTY);
		if (level != null) {
			var lookup = level.registryAccess().lookupOrThrow(net.minecraft.core.registries.Registries.ENCHANTMENT);
			fireAspectLevel = skilletStack.getEnchantmentLevel(lookup.getOrThrow(Enchantments.FIRE_ASPECT));
		} else fireAspectLevel = 0;
	}

	@Override
	public void saveAdditional(net.minecraft.world.level.storage.ValueOutput output) {
		super.saveAdditional(output);
		inventory.serialize(output);
		output.putInt("CookTime", cookingTime);
		output.putInt("CookTimeTotal", cookingTimeTotal);
		if (!skilletStack.isEmpty()) output.store("Skillet", ItemStack.CODEC, skilletStack);
	}

	public ItemStack getSkilletAsItem() {
		return skilletStack;
	}

	public void setSkilletItem(ItemStack stack) {
		skilletStack = stack.copy();
		if (level != null) {
			Optional<Holder.Reference<Enchantment>> fireAspect = level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).get(Enchantments.FIRE_ASPECT);
			fireAspectLevel = fireAspect.map(stack::getEnchantmentLevel).orElse(0);
		} else {
			fireAspectLevel = 0;
		}
		inventoryChanged();
	}

	public ItemStack addItemToCook(ItemStack addedStack, Player player) {
		Optional<RecipeHolder<CampfireCookingRecipe>> recipe = getMatchingRecipe(addedStack);
		if (recipe.isPresent() && getStoredStack().isEmpty()) {
			if (getBlockState().getValue(SkilletBlock.WATERLOGGED)) {
				player.sendSystemMessage(TextUtils.block("skillet.underwater"));
				return addedStack;
			}
			boolean wasEmpty = getStoredStack().isEmpty();
			ItemStack remainderStack = inventory.insertItem(0, addedStack.copy(), false);
			if (!ItemStack.matches(remainderStack, addedStack)) {
				cookingTimeTotal = SkilletBlock.getSkilletCookingTime(recipe.get().value().cookingTime(), fireAspectLevel);
				cookingTime = 0;
				if (wasEmpty && level != null && isHeated(level, worldPosition)) {
					level.playSound(null, worldPosition.getX() + 0.5F, worldPosition.getY() + 0.5F, worldPosition.getZ() + 0.5F, ModSounds.BLOCK_SKILLET_ADD_FOOD.get(), SoundSource.BLOCKS, 0.8F, 1.0F);
				}
				return remainderStack;
			}
		} else {
			player.sendSystemMessage(TextUtils.block("skillet.invalid_item"));
		}
		return addedStack;
	}

	public ItemStack removeItem() {
		return inventory.extractItem(0, getStoredStack().getMaxStackSize(), false);
	}

	public IItemHandler getInventory() {
		return inventory;
	}

	public ItemStack getStoredStack() {
		return inventory.getStackInSlot(0);
	}

	public boolean hasStoredStack() {
		return !getStoredStack().isEmpty();
	}

	private ItemStackHandler createHandler() {
		return new ItemStackHandler()
		{
			@Override
			protected void onContentsChanged(int slot) {
				inventoryChanged();
			}
		};
	}

	@Override
	public void setRemoved() {
		super.setRemoved();
	}

	@Override
	public void clearContent() {
		ItemUtils.clearItems(inventory);
	}
}
